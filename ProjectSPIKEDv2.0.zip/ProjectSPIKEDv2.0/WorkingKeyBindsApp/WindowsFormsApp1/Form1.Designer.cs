﻿namespace WindowsFormsApp1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cbxButton0 = new System.Windows.Forms.ComboBox();
            this.cbxButton1 = new System.Windows.Forms.ComboBox();
            this.cbxButton2 = new System.Windows.Forms.ComboBox();
            this.cbxButton3 = new System.Windows.Forms.ComboBox();
            this.cbxButton4 = new System.Windows.Forms.ComboBox();
            this.cbxButton5 = new System.Windows.Forms.ComboBox();
            this.cbxButton6 = new System.Windows.Forms.ComboBox();
            this.cbxButton7 = new System.Windows.Forms.ComboBox();
            this.cbxButton8 = new System.Windows.Forms.ComboBox();
            this.cbxButton9 = new System.Windows.Forms.ComboBox();
            this.cbxButton10 = new System.Windows.Forms.ComboBox();
            this.cbxButton11 = new System.Windows.Forms.ComboBox();
            this.cbxButton12 = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbMouse = new System.Windows.Forms.CheckBox();
            this.lblButton0 = new System.Windows.Forms.Label();
            this.lblButton1 = new System.Windows.Forms.Label();
            this.lblButton2 = new System.Windows.Forms.Label();
            this.lblButton3 = new System.Windows.Forms.Label();
            this.lblButton4 = new System.Windows.Forms.Label();
            this.lblButton5 = new System.Windows.Forms.Label();
            this.lblButton6 = new System.Windows.Forms.Label();
            this.lblButton7 = new System.Windows.Forms.Label();
            this.lblButton11 = new System.Windows.Forms.Label();
            this.lblButton10 = new System.Windows.Forms.Label();
            this.lblButton9 = new System.Windows.Forms.Label();
            this.lblButton8 = new System.Windows.Forms.Label();
            this.lblButton12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbxController = new System.Windows.Forms.ComboBox();
            this.not_spiked = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cbArrows = new System.Windows.Forms.CheckBox();
            this.btnConnectController = new System.Windows.Forms.Button();
            this.lblLeftTrigger = new System.Windows.Forms.Label();
            this.cbxLeftTrigger = new System.Windows.Forms.ComboBox();
            this.lblRightTrigger = new System.Windows.Forms.Label();
            this.cbxRightTrigger = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 40;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cbxButton0
            // 
            this.cbxButton0.DropDownHeight = 200;
            this.cbxButton0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton0.DropDownWidth = 155;
            this.cbxButton0.FormattingEnabled = true;
            this.cbxButton0.IntegralHeight = false;
            this.cbxButton0.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton0.Location = new System.Drawing.Point(151, 226);
            this.cbxButton0.Name = "cbxButton0";
            this.cbxButton0.Size = new System.Drawing.Size(155, 24);
            this.cbxButton0.TabIndex = 0;
            this.cbxButton0.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton1
            // 
            this.cbxButton1.DropDownHeight = 200;
            this.cbxButton1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton1.DropDownWidth = 155;
            this.cbxButton1.FormattingEnabled = true;
            this.cbxButton1.IntegralHeight = false;
            this.cbxButton1.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton1.Location = new System.Drawing.Point(151, 276);
            this.cbxButton1.Name = "cbxButton1";
            this.cbxButton1.Size = new System.Drawing.Size(155, 24);
            this.cbxButton1.TabIndex = 1;
            this.cbxButton1.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton2
            // 
            this.cbxButton2.DropDownHeight = 200;
            this.cbxButton2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton2.DropDownWidth = 155;
            this.cbxButton2.FormattingEnabled = true;
            this.cbxButton2.IntegralHeight = false;
            this.cbxButton2.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton2.Location = new System.Drawing.Point(151, 326);
            this.cbxButton2.Name = "cbxButton2";
            this.cbxButton2.Size = new System.Drawing.Size(155, 24);
            this.cbxButton2.TabIndex = 2;
            this.cbxButton2.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton3
            // 
            this.cbxButton3.DropDownHeight = 200;
            this.cbxButton3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton3.DropDownWidth = 155;
            this.cbxButton3.FormattingEnabled = true;
            this.cbxButton3.IntegralHeight = false;
            this.cbxButton3.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton3.Location = new System.Drawing.Point(151, 376);
            this.cbxButton3.Name = "cbxButton3";
            this.cbxButton3.Size = new System.Drawing.Size(155, 24);
            this.cbxButton3.TabIndex = 3;
            this.cbxButton3.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton4
            // 
            this.cbxButton4.DropDownHeight = 200;
            this.cbxButton4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton4.DropDownWidth = 155;
            this.cbxButton4.FormattingEnabled = true;
            this.cbxButton4.IntegralHeight = false;
            this.cbxButton4.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton4.Location = new System.Drawing.Point(479, 227);
            this.cbxButton4.Name = "cbxButton4";
            this.cbxButton4.Size = new System.Drawing.Size(155, 24);
            this.cbxButton4.TabIndex = 4;
            this.cbxButton4.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton5
            // 
            this.cbxButton5.DropDownHeight = 200;
            this.cbxButton5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton5.DropDownWidth = 155;
            this.cbxButton5.FormattingEnabled = true;
            this.cbxButton5.IntegralHeight = false;
            this.cbxButton5.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton5.Location = new System.Drawing.Point(479, 277);
            this.cbxButton5.Name = "cbxButton5";
            this.cbxButton5.Size = new System.Drawing.Size(155, 24);
            this.cbxButton5.TabIndex = 5;
            this.cbxButton5.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton6
            // 
            this.cbxButton6.DropDownHeight = 200;
            this.cbxButton6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton6.DropDownWidth = 155;
            this.cbxButton6.FormattingEnabled = true;
            this.cbxButton6.IntegralHeight = false;
            this.cbxButton6.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton6.Location = new System.Drawing.Point(479, 327);
            this.cbxButton6.Name = "cbxButton6";
            this.cbxButton6.Size = new System.Drawing.Size(155, 24);
            this.cbxButton6.TabIndex = 6;
            this.cbxButton6.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton7
            // 
            this.cbxButton7.DropDownHeight = 200;
            this.cbxButton7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton7.DropDownWidth = 155;
            this.cbxButton7.FormattingEnabled = true;
            this.cbxButton7.IntegralHeight = false;
            this.cbxButton7.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton7.Location = new System.Drawing.Point(479, 377);
            this.cbxButton7.Name = "cbxButton7";
            this.cbxButton7.Size = new System.Drawing.Size(155, 24);
            this.cbxButton7.TabIndex = 7;
            this.cbxButton7.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton8
            // 
            this.cbxButton8.DropDownHeight = 200;
            this.cbxButton8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton8.DropDownWidth = 155;
            this.cbxButton8.FormattingEnabled = true;
            this.cbxButton8.IntegralHeight = false;
            this.cbxButton8.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton8.Location = new System.Drawing.Point(803, 228);
            this.cbxButton8.Name = "cbxButton8";
            this.cbxButton8.Size = new System.Drawing.Size(155, 24);
            this.cbxButton8.TabIndex = 8;
            this.cbxButton8.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton9
            // 
            this.cbxButton9.DropDownHeight = 200;
            this.cbxButton9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton9.DropDownWidth = 155;
            this.cbxButton9.FormattingEnabled = true;
            this.cbxButton9.IntegralHeight = false;
            this.cbxButton9.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton9.Location = new System.Drawing.Point(803, 278);
            this.cbxButton9.Name = "cbxButton9";
            this.cbxButton9.Size = new System.Drawing.Size(155, 24);
            this.cbxButton9.TabIndex = 9;
            this.cbxButton9.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton10
            // 
            this.cbxButton10.DropDownHeight = 200;
            this.cbxButton10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton10.DropDownWidth = 155;
            this.cbxButton10.FormattingEnabled = true;
            this.cbxButton10.IntegralHeight = false;
            this.cbxButton10.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton10.Location = new System.Drawing.Point(803, 328);
            this.cbxButton10.Name = "cbxButton10";
            this.cbxButton10.Size = new System.Drawing.Size(155, 24);
            this.cbxButton10.TabIndex = 10;
            this.cbxButton10.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton11
            // 
            this.cbxButton11.DropDownHeight = 200;
            this.cbxButton11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton11.DropDownWidth = 155;
            this.cbxButton11.FormattingEnabled = true;
            this.cbxButton11.IntegralHeight = false;
            this.cbxButton11.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton11.Location = new System.Drawing.Point(803, 378);
            this.cbxButton11.Name = "cbxButton11";
            this.cbxButton11.Size = new System.Drawing.Size(155, 24);
            this.cbxButton11.TabIndex = 11;
            this.cbxButton11.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // cbxButton12
            // 
            this.cbxButton12.DropDownHeight = 200;
            this.cbxButton12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxButton12.DropDownWidth = 155;
            this.cbxButton12.FormattingEnabled = true;
            this.cbxButton12.IntegralHeight = false;
            this.cbxButton12.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxButton12.Location = new System.Drawing.Point(1106, 226);
            this.cbxButton12.Name = "cbxButton12";
            this.cbxButton12.Size = new System.Drawing.Size(155, 24);
            this.cbxButton12.TabIndex = 12;
            this.cbxButton12.SelectedIndexChanged += new System.EventHandler(this.cbxKeybindBoxChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1319, 28);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.refreshToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.saveAsToolStripMenuItem.Text = "Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // cbMouse
            // 
            this.cbMouse.AutoSize = true;
            this.cbMouse.BackColor = System.Drawing.Color.Transparent;
            this.cbMouse.Location = new System.Drawing.Point(448, 80);
            this.cbMouse.Name = "cbMouse";
            this.cbMouse.Size = new System.Drawing.Size(195, 21);
            this.cbMouse.TabIndex = 14;
            this.cbMouse.Text = " Use Right Stick as Mouse";
            this.cbMouse.UseVisualStyleBackColor = false;
            // 
            // lblButton0
            // 
            this.lblButton0.BackColor = System.Drawing.Color.Transparent;
            this.lblButton0.Location = new System.Drawing.Point(45, 226);
            this.lblButton0.Name = "lblButton0";
            this.lblButton0.Size = new System.Drawing.Size(100, 24);
            this.lblButton0.TabIndex = 15;
            this.lblButton0.Text = "Square:";
            this.lblButton0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton1
            // 
            this.lblButton1.BackColor = System.Drawing.Color.Transparent;
            this.lblButton1.Location = new System.Drawing.Point(45, 276);
            this.lblButton1.Name = "lblButton1";
            this.lblButton1.Size = new System.Drawing.Size(100, 24);
            this.lblButton1.TabIndex = 16;
            this.lblButton1.Text = "Cross:";
            this.lblButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton2
            // 
            this.lblButton2.BackColor = System.Drawing.Color.Transparent;
            this.lblButton2.Location = new System.Drawing.Point(45, 326);
            this.lblButton2.Name = "lblButton2";
            this.lblButton2.Size = new System.Drawing.Size(100, 24);
            this.lblButton2.TabIndex = 17;
            this.lblButton2.Text = "Circle:";
            this.lblButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton3
            // 
            this.lblButton3.BackColor = System.Drawing.Color.Transparent;
            this.lblButton3.Location = new System.Drawing.Point(45, 376);
            this.lblButton3.Name = "lblButton3";
            this.lblButton3.Size = new System.Drawing.Size(100, 24);
            this.lblButton3.TabIndex = 18;
            this.lblButton3.Text = "Triangle:";
            this.lblButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton4
            // 
            this.lblButton4.BackColor = System.Drawing.Color.Transparent;
            this.lblButton4.Location = new System.Drawing.Point(356, 225);
            this.lblButton4.Name = "lblButton4";
            this.lblButton4.Size = new System.Drawing.Size(117, 24);
            this.lblButton4.TabIndex = 19;
            this.lblButton4.Text = "L1:";
            this.lblButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton5
            // 
            this.lblButton5.BackColor = System.Drawing.Color.Transparent;
            this.lblButton5.Location = new System.Drawing.Point(356, 276);
            this.lblButton5.Name = "lblButton5";
            this.lblButton5.Size = new System.Drawing.Size(117, 24);
            this.lblButton5.TabIndex = 20;
            this.lblButton5.Text = "R1:";
            this.lblButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton6
            // 
            this.lblButton6.BackColor = System.Drawing.Color.Transparent;
            this.lblButton6.Location = new System.Drawing.Point(356, 326);
            this.lblButton6.Name = "lblButton6";
            this.lblButton6.Size = new System.Drawing.Size(117, 24);
            this.lblButton6.TabIndex = 21;
            this.lblButton6.Text = "L2:";
            this.lblButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton7
            // 
            this.lblButton7.BackColor = System.Drawing.Color.Transparent;
            this.lblButton7.Location = new System.Drawing.Point(356, 376);
            this.lblButton7.Name = "lblButton7";
            this.lblButton7.Size = new System.Drawing.Size(117, 24);
            this.lblButton7.TabIndex = 22;
            this.lblButton7.Text = "R2:";
            this.lblButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton11
            // 
            this.lblButton11.BackColor = System.Drawing.Color.Transparent;
            this.lblButton11.Location = new System.Drawing.Point(697, 377);
            this.lblButton11.Name = "lblButton11";
            this.lblButton11.Size = new System.Drawing.Size(100, 24);
            this.lblButton11.TabIndex = 26;
            this.lblButton11.Text = "Right Thumb:";
            this.lblButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton10
            // 
            this.lblButton10.BackColor = System.Drawing.Color.Transparent;
            this.lblButton10.Location = new System.Drawing.Point(697, 327);
            this.lblButton10.Name = "lblButton10";
            this.lblButton10.Size = new System.Drawing.Size(100, 24);
            this.lblButton10.TabIndex = 25;
            this.lblButton10.Text = "Left Thumb:";
            this.lblButton10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton9
            // 
            this.lblButton9.BackColor = System.Drawing.Color.Transparent;
            this.lblButton9.Location = new System.Drawing.Point(697, 277);
            this.lblButton9.Name = "lblButton9";
            this.lblButton9.Size = new System.Drawing.Size(100, 24);
            this.lblButton9.TabIndex = 24;
            this.lblButton9.Text = "Options:";
            this.lblButton9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton8
            // 
            this.lblButton8.BackColor = System.Drawing.Color.Transparent;
            this.lblButton8.Location = new System.Drawing.Point(697, 227);
            this.lblButton8.Name = "lblButton8";
            this.lblButton8.Size = new System.Drawing.Size(100, 24);
            this.lblButton8.TabIndex = 23;
            this.lblButton8.Text = "Share:";
            this.lblButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblButton12
            // 
            this.lblButton12.BackColor = System.Drawing.Color.Transparent;
            this.lblButton12.Location = new System.Drawing.Point(1000, 227);
            this.lblButton12.Name = "lblButton12";
            this.lblButton12.Size = new System.Drawing.Size(100, 24);
            this.lblButton12.TabIndex = 28;
            this.lblButton12.Text = "Touchpad:";
            this.lblButton12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(61, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 24);
            this.label5.TabIndex = 30;
            this.label5.Text = "Type of Controller:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxController
            // 
            this.cbxController.DropDownHeight = 200;
            this.cbxController.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxController.DropDownWidth = 155;
            this.cbxController.FormattingEnabled = true;
            this.cbxController.IntegralHeight = false;
            this.cbxController.Items.AddRange(new object[] {
            "Playstation 4",
            "Xbox 360"});
            this.cbxController.Location = new System.Drawing.Point(222, 78);
            this.cbxController.Name = "cbxController";
            this.cbxController.Size = new System.Drawing.Size(155, 24);
            this.cbxController.TabIndex = 29;
            this.cbxController.SelectedIndexChanged += new System.EventHandler(this.cbxController_SelectedIndexChanged);
            // 
            // not_spiked
            // 
            this.not_spiked.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.not_spiked.BalloonTipText = "Your aplication is still running";
            this.not_spiked.ContextMenuStrip = this.contextMenuStrip1;
            this.not_spiked.Icon = ((System.Drawing.Icon)(resources.GetObject("not_spiked.Icon")));
            this.not_spiked.Text = "notifyIcon1";
            this.not_spiked.Visible = true;
            this.not_spiked.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.not_spiked_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openWindowToolStripMenuItem,
            this.exitToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(174, 52);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // openWindowToolStripMenuItem
            // 
            this.openWindowToolStripMenuItem.Name = "openWindowToolStripMenuItem";
            this.openWindowToolStripMenuItem.Size = new System.Drawing.Size(173, 24);
            this.openWindowToolStripMenuItem.Text = "Open Window";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(173, 24);
            this.exitToolStripMenuItem1.Text = "Exit";
            // 
            // cbArrows
            // 
            this.cbArrows.AutoSize = true;
            this.cbArrows.BackColor = System.Drawing.Color.Transparent;
            this.cbArrows.Location = new System.Drawing.Point(448, 122);
            this.cbArrows.Name = "cbArrows";
            this.cbArrows.Size = new System.Drawing.Size(187, 21);
            this.cbArrows.TabIndex = 31;
            this.cbArrows.Text = " Use Left Stick as Arrows";
            this.cbArrows.UseVisualStyleBackColor = false;
            // 
            // btnConnectController
            // 
            this.btnConnectController.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnConnectController.Location = new System.Drawing.Point(220, 117);
            this.btnConnectController.Name = "btnConnectController";
            this.btnConnectController.Size = new System.Drawing.Size(159, 28);
            this.btnConnectController.TabIndex = 32;
            this.btnConnectController.Text = "Connect Controller";
            this.btnConnectController.UseVisualStyleBackColor = true;
            this.btnConnectController.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // lblLeftTrigger
            // 
            this.lblLeftTrigger.BackColor = System.Drawing.Color.Transparent;
            this.lblLeftTrigger.Location = new System.Drawing.Point(1000, 277);
            this.lblLeftTrigger.Name = "lblLeftTrigger";
            this.lblLeftTrigger.Size = new System.Drawing.Size(100, 24);
            this.lblLeftTrigger.TabIndex = 34;
            this.lblLeftTrigger.Text = "Left Trigger:";
            this.lblLeftTrigger.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxLeftTrigger
            // 
            this.cbxLeftTrigger.DropDownHeight = 200;
            this.cbxLeftTrigger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxLeftTrigger.DropDownWidth = 155;
            this.cbxLeftTrigger.FormattingEnabled = true;
            this.cbxLeftTrigger.IntegralHeight = false;
            this.cbxLeftTrigger.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxLeftTrigger.Location = new System.Drawing.Point(1106, 276);
            this.cbxLeftTrigger.Name = "cbxLeftTrigger";
            this.cbxLeftTrigger.Size = new System.Drawing.Size(155, 24);
            this.cbxLeftTrigger.TabIndex = 33;
            // 
            // lblRightTrigger
            // 
            this.lblRightTrigger.BackColor = System.Drawing.Color.Transparent;
            this.lblRightTrigger.Location = new System.Drawing.Point(1000, 327);
            this.lblRightTrigger.Name = "lblRightTrigger";
            this.lblRightTrigger.Size = new System.Drawing.Size(100, 24);
            this.lblRightTrigger.TabIndex = 36;
            this.lblRightTrigger.Text = "Right Trigger";
            this.lblRightTrigger.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxRightTrigger
            // 
            this.cbxRightTrigger.DropDownHeight = 200;
            this.cbxRightTrigger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxRightTrigger.DropDownWidth = 155;
            this.cbxRightTrigger.FormattingEnabled = true;
            this.cbxRightTrigger.IntegralHeight = false;
            this.cbxRightTrigger.Items.AddRange(new object[] {
            "",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "Left Click",
            "Right Click",
            "Spacebar",
            "Left Ctrl",
            "Right Ctrl",
            "Alt",
            "Tab",
            "Left Shift",
            "Right Shift",
            "Left Windows Button",
            "Right Windows Button",
            "Esc",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "F11",
            "F12",
            "Backspace",
            "Delete",
            "Up Arrow",
            "Right Arrow",
            "Down Arrow",
            "Left Arrow",
            "Enter/Return",
            "Tilda (~)",
            "Dash (-)",
            "Equals (=)",
            "Left Bracket ([)",
            "Right Bracket (])",
            "Backslash (\\)",
            "Semicolon (;)",
            "Quotes (\"\")",
            "Comma (,)",
            "Period (.)",
            "Fowardslash (/)"});
            this.cbxRightTrigger.Location = new System.Drawing.Point(1106, 326);
            this.cbxRightTrigger.Name = "cbxRightTrigger";
            this.cbxRightTrigger.Size = new System.Drawing.Size(155, 24);
            this.cbxRightTrigger.TabIndex = 35;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1319, 465);
            this.Controls.Add(this.lblRightTrigger);
            this.Controls.Add(this.cbxRightTrigger);
            this.Controls.Add(this.lblLeftTrigger);
            this.Controls.Add(this.cbxLeftTrigger);
            this.Controls.Add(this.btnConnectController);
            this.Controls.Add(this.cbArrows);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbxController);
            this.Controls.Add(this.lblButton12);
            this.Controls.Add(this.lblButton11);
            this.Controls.Add(this.lblButton10);
            this.Controls.Add(this.lblButton9);
            this.Controls.Add(this.lblButton8);
            this.Controls.Add(this.lblButton7);
            this.Controls.Add(this.lblButton6);
            this.Controls.Add(this.lblButton5);
            this.Controls.Add(this.lblButton4);
            this.Controls.Add(this.lblButton3);
            this.Controls.Add(this.lblButton2);
            this.Controls.Add(this.lblButton1);
            this.Controls.Add(this.lblButton0);
            this.Controls.Add(this.cbMouse);
            this.Controls.Add(this.cbxButton12);
            this.Controls.Add(this.cbxButton11);
            this.Controls.Add(this.cbxButton10);
            this.Controls.Add(this.cbxButton9);
            this.Controls.Add(this.cbxButton8);
            this.Controls.Add(this.cbxButton7);
            this.Controls.Add(this.cbxButton6);
            this.Controls.Add(this.cbxButton5);
            this.Controls.Add(this.cbxButton4);
            this.Controls.Add(this.cbxButton3);
            this.Controls.Add(this.cbxButton2);
            this.Controls.Add(this.cbxButton1);
            this.Controls.Add(this.cbxButton0);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1337, 512);
            this.MinimumSize = new System.Drawing.Size(1337, 512);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project S.P.I.K.E.D.";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox cbxButton0;
        private System.Windows.Forms.ComboBox cbxButton1;
        private System.Windows.Forms.ComboBox cbxButton2;
        private System.Windows.Forms.ComboBox cbxButton3;
        private System.Windows.Forms.ComboBox cbxButton4;
        private System.Windows.Forms.ComboBox cbxButton5;
        private System.Windows.Forms.ComboBox cbxButton6;
        private System.Windows.Forms.ComboBox cbxButton7;
        private System.Windows.Forms.ComboBox cbxButton8;
        private System.Windows.Forms.ComboBox cbxButton9;
        private System.Windows.Forms.ComboBox cbxButton10;
        private System.Windows.Forms.ComboBox cbxButton11;
        private System.Windows.Forms.ComboBox cbxButton12;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.CheckBox cbMouse;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.Label lblButton0;
        private System.Windows.Forms.Label lblButton1;
        private System.Windows.Forms.Label lblButton2;
        private System.Windows.Forms.Label lblButton3;
        private System.Windows.Forms.Label lblButton4;
        private System.Windows.Forms.Label lblButton5;
        private System.Windows.Forms.Label lblButton6;
        private System.Windows.Forms.Label lblButton7;
        private System.Windows.Forms.Label lblButton11;
        private System.Windows.Forms.Label lblButton10;
        private System.Windows.Forms.Label lblButton9;
        private System.Windows.Forms.Label lblButton8;
        private System.Windows.Forms.Label lblButton12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbxController;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.NotifyIcon not_spiked;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem openWindowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.CheckBox cbArrows;
        private System.Windows.Forms.Button btnConnectController;
        private System.Windows.Forms.Label lblLeftTrigger;
        private System.Windows.Forms.ComboBox cbxLeftTrigger;
        private System.Windows.Forms.Label lblRightTrigger;
        private System.Windows.Forms.ComboBox cbxRightTrigger;
    }
}

