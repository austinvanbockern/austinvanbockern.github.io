﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SlimDX.DirectInput;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;

/********************************
// PROJECT S.P.I.K.E.D.
// Special
// Project:
// Improve
// "Keybinding
// Environment"
// Development
// V.2.0
// AUSTIN MICHAEL VAN BOCKERN
// 
// ANDREW ROCKFORD MADDOX
********************************/

namespace WindowsFormsApp1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            GetSticks();
            Sticks = GetSticks();
            timer1.Enabled = true;
        }

        DirectInput Input = new DirectInput();
        Joystick stick;
        Joystick[] Sticks;
        
        //Creating instance of menu for notification icon
        private ContextMenu m_menu;

        bool[] buttons;
        bool[] buttonsLogic = { false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false,
                                false};
        bool rightClick = false;
        bool leftClick = false;

        //VK_Binds Array refer to project S.P.I.K.E.D. notbook for order
        byte[] buttonBindings =
                               {0x00,
                                0x41,
                                0x42,
                                0x43,
                                0x44,
                                0x45,
                                0x46,
                                0x47,
                                0x48,
                                0x49,
                                0x4A,
                                0x4B,
                                0x4C,
                                0x4D,
                                0x4E,
                                0x4F,
                                0x50,
                                0x51,
                                0x52,
                                0x53,
                                0x54,
                                0x55,
                                0x56,
                                0x57,
                                0x58,
                                0x59,
                                0x5A,
                                0x30,
                                0x31,
                                0x32,
                                0x33,
                                0x34,
                                0x35,
                                0x36,
                                0x37,
                                0x38,
                                0x39,
                                0x01,
                                0x02,
                                0x20,
                                0xA2,
                                0xA3,
                                0x12,
                                0x09,
                                0xA0,
                                0xA1,
                                0x5B,
                                0x5C,
                                0x1B,
                                0x70,
                                0x71,
                                0x72,
                                0x73,
                                0x74,
                                0x75,
                                0x76,
                                0x77,
                                0x78,
                                0x79,
                                0x7A,
                                0x7B,
                                0x08,
                                0x2E,
                                0x26,
                                0x27,
                                0x28,
                                0x25,
                                0x0D,
                                0xC0,
                                0xBD,
                                0xBB,
                                0xDB,
                                0xDD,
                                0xDC,
                                0xBA,
                                0xDE,
                                0xBC,
                                0xBE,
                                0xBF};

        // Arrays containing the names of the xbox and playstation buttons
        string[] playstationButtons = { "Square:", "Cross:", "Circle:", "Triangle:", "L1:", "R1:", "L2:", "R2:", "Share:", "Options:", "Left Thumb:", "Right Thumb:", "Touchpad:" };
        string[] xboxButtons = { "A Button:", "B Button:", "X Button:", "Y Button:", "Left Bumper:", "Right Bumper:", "Select:", "Start:", "Left Thumb:", "Right Thumb:" };

        int yLeft = 0;
        int xLeft = 0;
        int yRight = 0;
        int xRight = 0;
        int triggerState = 0;

        string savedFileName = "";
        bool fileOpened = false;
        bool changesMade = false;

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern void mouse_event(uint flag, uint _x, uint _y, uint btn, uint exInfo);
        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo);

        private const int MOUSEEVENT_LEFTDOWN = 0x02;
        private const int MOUSEEVENT_LEFTUP = 0x04;
        private const int MOUSEEVENT_RIGHTDOWN = 0x08;
        private const int MOUSEEVENT_RIGHTUP = 0x10;

        public Joystick[] GetSticks()
        {
            List<Joystick> sticks = new List<Joystick>();
            foreach (DeviceInstance device in Input.GetDevices(DeviceClass.GameController, DeviceEnumerationFlags.AttachedOnly))
            {
                try
                {
                    stick = new Joystick(Input, device.InstanceGuid);
                    stick.Acquire();

                    foreach (DeviceObjectInstance deviceObject in stick.GetObjects())
                    {
                        if ((deviceObject.ObjectType & ObjectDeviceType.Axis) !=0 )
                        {
                            stick.GetObjectPropertiesById((int)deviceObject.ObjectType).SetRange(-100, 100);
                        }
                    }
                    sticks.Add(stick);

                }
                catch (DirectInputException)
                { }
            }
            return sticks.ToArray();

        }

        void stickHandle(Joystick stick, int id)
        {
            JoystickState state = new JoystickState();
            state = stick.GetCurrentState();
            yLeft = state.Y;
            xLeft = state.X;

            if (cbxController.SelectedIndex == 0)
            {
                yRight = state.RotationZ;
                xRight = state.Z;
            }
            else if (cbxController.SelectedIndex == 1)
            {
                yRight = state.RotationY;
                xRight = state.RotationX;
                triggerState = state.Z;
            }
            
            

            // If user wants right analog stick to control mouse
            if (cbMouse.Checked)
            {
                MouseMove(xRight, yRight);
            }

            // state.RotationX & state.RotationY ARE FOR RIGHT ANALOG STICK

            // state.Z is for L + R triggers on Xbox 360
            // -100 is right, 100 is left

            // Get input
            buttons = state.GetButtons();
            buttons[12] = buttons[13];

            // Handles first stick
            if (id == 0)
            {
                /* If a button is pressed, simulates a key being pressed.
                 * The key being pressed is determined by which item is selected in that buttons ComboBox.
                 * There is an array named "buttonBindings" containing the hexcodes for each key on the keyboard.
                 * The index of the array containing the code for that letter
                 * is also the index for that letter in the combo box.
                 * If the selected item is a mouse click (index 37 & 38),
                 * it detects it and uses the mouse_event method instead of the keybd_event method.
                 * Code simulates the button being pressed and 
                 * waits for the key to be unpressed to run the unpress code
                 * -AVB-9/8/2017-
                 */

                // Right and Left Triggers for Xbox 360
                if (cbxController.SelectedIndex == 1)
                {
                    // Left Trigger
                    if (triggerState > 50)
                    {
                        HandleKeyPress(cbxLeftTrigger.SelectedIndex, 17);
                    }
                    else if (buttonsLogic[17])
                    {
                        keybd_event(buttonBindings[cbxLeftTrigger.SelectedIndex], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[17] = false;
                    }
                    else if (buttonsLogic[17] && rightClick)
                    {
                        mouse_event(MOUSEEVENT_RIGHTUP, 0, 0, 0, 0);

                        buttonsLogic[17] = false;
                        rightClick = false;
                    }
                    else if (buttonsLogic[17] && leftClick)
                    {
                        mouse_event(MOUSEEVENT_LEFTUP, 0, 0, 0, 0);

                        buttonsLogic[17] = false;
                        leftClick = false;
                    }
                    // Right trigger
                    if (triggerState < -50)
                    {
                        HandleKeyPress(cbxRightTrigger.SelectedIndex, 18);
                    }
                    else if (buttonsLogic[18] && rightClick)
                    {
                        mouse_event(MOUSEEVENT_RIGHTUP, 0, 0, 0, 0);

                        buttonsLogic[18] = false;
                        rightClick = false;
                    }
                    else if (buttonsLogic[18] && leftClick)
                    {
                        mouse_event(MOUSEEVENT_LEFTUP, 0, 0, 0, 0);

                        buttonsLogic[18] = false;
                        leftClick = false;
                    }
                    else if (buttonsLogic[18])
                    {
                        keybd_event(buttonBindings[cbxRightTrigger.SelectedIndex], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[18] = false;
                    } 
                }
                

                // Left Stick as Arrows Logic
                if (cbArrows.Checked)
                {
                    // UP
                    if (yLeft < -50)
                    {
                        HandleKeyPress(63, 13);
                    }
                    else if (buttonsLogic[13])
                    {
                        keybd_event(buttonBindings[63], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[13] = false;
                    }
                    // DOWN
                    if (yLeft > 50)
                    {
                        HandleKeyPress(65, 14);
                    }
                    else if (buttonsLogic[14])
                    {
                        keybd_event(buttonBindings[65], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[14] = false;
                    }
                    // LEFT
                    if (xLeft < -50)
                    {
                        HandleKeyPress(66, 15);
                    }
                    else if (buttonsLogic[15])
                    {
                        keybd_event(buttonBindings[66], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[15] = false;
                    }
                    // RIGHT
                    if (xLeft > 50)
                    {
                        HandleKeyPress(64, 16);
                    }
                    else if (buttonsLogic[16])
                    {
                        keybd_event(buttonBindings[64], 0, 0x0001 | 0x0002, 0);

                        buttonsLogic[16] = false;
                    } 
                }


                // Button 0
                HandleButton(cbxButton0.SelectedIndex, 0);
                // Button 1
                HandleButton(cbxButton1.SelectedIndex, 1);
                // Button 2
                HandleButton(cbxButton2.SelectedIndex, 2);
                // Button 3
                HandleButton(cbxButton3.SelectedIndex, 3);
                // Button 4
                HandleButton(cbxButton4.SelectedIndex, 4);
                // Button 5
                HandleButton(cbxButton5.SelectedIndex, 5);
                // Button 6
                HandleButton(cbxButton6.SelectedIndex, 6);
                // Button 7
                HandleButton(cbxButton7.SelectedIndex, 7);
                // Button 8
                HandleButton(cbxButton8.SelectedIndex, 8);
                // Button 9
                HandleButton(cbxButton9.SelectedIndex, 9);
                // Button 10
                HandleButton(cbxButton10.SelectedIndex, 10);
                // Button 11
                HandleButton(cbxButton11.SelectedIndex, 11);
                // Button 13
                HandleButton(cbxButton12.SelectedIndex, 12);
            }
        }

        public void MouseMove(int posx, int posy)
        {
            // Move mouse with Left Analog Stick
            // make stick less sensitive
            if (posx > 25 || posx < -25 || posy > 25 || posy < -25)
            {
                Cursor.Position = new Point(Cursor.Position.X + posx / 3, Cursor.Position.Y + posy / 3);
            }


            //Cursor.Clip = new Rectangle(this.Location, this.Size);
        }
     
        private void Form1_Load(object sender, EventArgs e)
        {
            // Get all sticks connected
            Joystick[] joystick = GetSticks();

            // Set keybindings to null
            ClearBinds();

            // Default Controller Playstation
            cbxController.SelectedIndex = 0;

            changesMade = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {            
            // Get input for each stick
            for (int i = 0; i < Sticks.Length; i++)
            {
                stickHandle(Sticks[i], i);
            }
            
        }

        private void cbxController_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxController.SelectedIndex == 0)
            {
                // Set labels for PS4
                lblButton0.Text = playstationButtons[0];
                lblButton1.Text = playstationButtons[1];
                lblButton2.Text = playstationButtons[2];
                lblButton3.Text = playstationButtons[3];
                lblButton4.Text = playstationButtons[4];
                lblButton5.Text = playstationButtons[5];
                lblButton6.Text = playstationButtons[6];
                lblButton7.Text = playstationButtons[7];
                lblButton8.Text = playstationButtons[8];
                lblButton9.Text = playstationButtons[9];
                lblButton10.Text = playstationButtons[10];
                lblButton11.Text = playstationButtons[11];
                lblButton12.Text = playstationButtons[12];

                // PS4 boxes visible
                cbxButton10.Visible = true;
                cbxButton11.Visible = true;
                cbxButton12.Visible = true;

                // Xbox360 boxes invisible
                cbxLeftTrigger.Visible = false;
                cbxRightTrigger.Visible = false;
                lblLeftTrigger.Visible = false;
                lblRightTrigger.Visible = false;

            }
            else if (cbxController.SelectedIndex == 1)
            {
                // Set labels for Xbox 360
                lblButton0.Text = xboxButtons[0];
                lblButton1.Text = xboxButtons[1];
                lblButton2.Text = xboxButtons[2];
                lblButton3.Text = xboxButtons[3];
                lblButton4.Text = xboxButtons[4];
                lblButton5.Text = xboxButtons[5];
                lblButton6.Text = xboxButtons[6];
                lblButton7.Text = xboxButtons[7];
                lblButton8.Text = xboxButtons[8];
                lblButton9.Text = xboxButtons[9];
                lblButton10.Text = "";
                lblButton11.Text = "";
                lblButton12.Text = "";

                // PS4 boxes invisible
                cbxButton10.Visible = false;
                cbxButton11.Visible = false;
                cbxButton12.Visible = false;

                // Xbox360 boxes visible
                cbxLeftTrigger.Visible = true;
                cbxRightTrigger.Visible = true;
                lblLeftTrigger.Visible = true;
                lblRightTrigger.Visible = true;
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // If there have been changes made to keybinds,
            // let user know these changes will not be saved if they exit now.
            if (changesMade)
            {
                DialogResult r = MessageBox.Show("By clicking yes, this will clear all keybindings set on the form and unsaved progress will be lost.", "Project: S.P.I.K.E.D", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (r == DialogResult.Yes)
                {
                    ClearBinds();

                    // reset bool for save, open, new
                    fileOpened = false;
                    changesMade = false;

                    // Reset form text
                    this.Text = "Project S.P.I.K.E.D";
                }
            }
            // If changes have not been made,
            // clear keybinds
            else
            {
                ClearBinds();

                // reset bool for save, open, new
                fileOpened = false;
                changesMade = false;

                // Reset form text
                this.Text = "Project S.P.I.K.E.D";
            }


        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Get keybinds and store in array
            string[] saveData = {   cbxButton0.SelectedIndex.ToString(),
                                    cbxButton1.SelectedIndex.ToString(),
                                    cbxButton2.SelectedIndex.ToString(),
                                    cbxButton3.SelectedIndex.ToString(),
                                    cbxButton4.SelectedIndex.ToString(),
                                    cbxButton5.SelectedIndex.ToString(),
                                    cbxButton6.SelectedIndex.ToString(),
                                    cbxButton7.SelectedIndex.ToString(),
                                    cbxButton8.SelectedIndex.ToString(),
                                    cbxButton9.SelectedIndex.ToString(),
                                    cbxButton10.SelectedIndex.ToString(),
                                    cbxButton11.SelectedIndex.ToString(),
                                    cbxButton12.SelectedIndex.ToString(),
                                    cbxLeftTrigger.SelectedIndex.ToString(),
                                    cbxRightTrigger.SelectedIndex.ToString() };

            // Make SaveFileDialog object for saving file and set its properties
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "dat files (*.dat)|*.dat";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.DefaultExt = ".dat";


            // If they have opened a file and are now trying to save, overwrite that file
            if (fileOpened)
            {
                try
                {
                    // Write to file
                    System.IO.File.WriteAllLines(@"" + savedFileName, saveData);

                    MessageBox.Show("Changes saved.");

                    changesMade = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error has occured:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            // Else, save the file as the name they typed
            else if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Write to file
                    System.IO.File.WriteAllLines(@"" + saveFileDialog.FileName, saveData);

                    // Change title of form to include the file name they opened
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.FileName = saveFileDialog.FileName;
                    this.Text = "Project S.P.I.K.E.D. - " + openFileDialog.SafeFileName;

                    // Set file name for saving later
                    savedFileName = saveFileDialog.FileName;

                    // File has been opened, changes have not been made
                    fileOpened = true;
                    changesMade = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error has occured:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Make SaveFileDialog object for saving file and set its properties
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "dat files (*.dat)|*.dat";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.DefaultExt = ".dat";

            // If user presses ok in the dialog window
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Array for the file they are opening
                    string[] openData = new string[15];

                    // Get data from file and assign it to array
                    openData = System.IO.File.ReadAllLines(openFileDialog.FileName);

                    // Change title of form to include the file name they opened
                    this.Text = "Project S.P.I.K.E.D. - " + openFileDialog.SafeFileName;

                    // They opened a file
                    fileOpened = true;

                    // Set class level variable to the filename they selected
                    savedFileName = openFileDialog.FileName;

                    // Set keybinds to the data from the file they selected
                    cbxButton0.SelectedIndex = int.Parse(openData[0]);
                    cbxButton1.SelectedIndex = int.Parse(openData[1]);
                    cbxButton2.SelectedIndex = int.Parse(openData[2]);
                    cbxButton3.SelectedIndex = int.Parse(openData[3]);
                    cbxButton4.SelectedIndex = int.Parse(openData[4]);
                    cbxButton5.SelectedIndex = int.Parse(openData[5]);
                    cbxButton6.SelectedIndex = int.Parse(openData[6]);
                    cbxButton7.SelectedIndex = int.Parse(openData[7]);
                    cbxButton8.SelectedIndex = int.Parse(openData[8]);
                    cbxButton9.SelectedIndex = int.Parse(openData[9]);
                    cbxButton10.SelectedIndex = int.Parse(openData[10]);
                    cbxButton11.SelectedIndex = int.Parse(openData[11]);
                    cbxButton12.SelectedIndex = int.Parse(openData[12]);
                    cbxLeftTrigger.SelectedIndex = int.Parse(openData[13]);
                    cbxRightTrigger.SelectedIndex = int.Parse(openData[14]);

                    // Changes have not been made
                    changesMade = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error has occured:\n\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cbxKeybindBoxChanged(object sender, EventArgs e)
        {
            // Turns to true if changes have been made to binds on form
            changesMade = true;
        }

        // Method to clear all binds on the form
        private void ClearBinds()
        {
            cbxButton0.SelectedIndex = 0;
            cbxButton1.SelectedIndex = 0;
            cbxButton2.SelectedIndex = 0;
            cbxButton3.SelectedIndex = 0;
            cbxButton4.SelectedIndex = 0;
            cbxButton5.SelectedIndex = 0;
            cbxButton6.SelectedIndex = 0;
            cbxButton7.SelectedIndex = 0;
            cbxButton8.SelectedIndex = 0;
            cbxButton9.SelectedIndex = 0;
            cbxButton10.SelectedIndex = 0;
            cbxButton11.SelectedIndex = 0;
            cbxButton12.SelectedIndex = 0;
            cbxLeftTrigger.SelectedIndex = 0;
            cbxRightTrigger.SelectedIndex = 0;
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Get keybinds and store in array
            string[] saveData = {   cbxButton0.SelectedIndex.ToString(),
                                    cbxButton1.SelectedIndex.ToString(),
                                    cbxButton2.SelectedIndex.ToString(),
                                    cbxButton3.SelectedIndex.ToString(),
                                    cbxButton4.SelectedIndex.ToString(),
                                    cbxButton5.SelectedIndex.ToString(),
                                    cbxButton6.SelectedIndex.ToString(),
                                    cbxButton7.SelectedIndex.ToString(),
                                    cbxButton8.SelectedIndex.ToString(),
                                    cbxButton9.SelectedIndex.ToString(),
                                    cbxButton10.SelectedIndex.ToString(),
                                    cbxButton11.SelectedIndex.ToString(),
                                    cbxButton12.SelectedIndex.ToString(),
                                    cbxLeftTrigger.SelectedIndex.ToString(),
                                    cbxRightTrigger.SelectedIndex.ToString() };

            // Make SaveFileDialog object for saving file and set its properties
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "dat files (*.dat)|*.dat";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.DefaultExt = ".dat";

            // Save the file as the name they typed
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Write to file
                    System.IO.File.WriteAllLines(@"" + saveFileDialog.FileName, saveData);

                    // Change title of form to include the file name they opened
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.FileName = saveFileDialog.FileName;
                    this.Text = "Project S.P.I.K.E.D. - " + openFileDialog.SafeFileName;

                    savedFileName = openFileDialog.FileName;
                    fileOpened = true;
                    changesMade = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An unexpected error has occured:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Run override method
            // statement triggers override method
            this.Close();
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Get all sticks connected
            Sticks = GetSticks();
        }

        // override for red X button 
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            // When user decides to exit, make sure they aren't losing progress on their saves.
            // If they made changes on the form and there is already a saved

            // IN THIS OVERRIED, DOING NOTHING CLOSES THE FORM
            // YOU MUST SPECIFY e.Cancel IN ORDER TO CANCEL THE CLOSING
            if (changesMade && fileOpened)
            {
                // Ask user if they'd like to save the changes they made
                DialogResult exitSaving = MessageBox.Show("There are unsaved changes your file.\n\nWould you like to save these changes?", "Project: S.P.I.K.E.D", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                // If they want to save, overwrite the file already saved
                if (exitSaving == DialogResult.Yes)
                {
                    // Try to overwrite file
                    try
                    {
                        // Get keybinds and store in array
                        string[] saveData = {   cbxButton0.SelectedIndex.ToString(),
                                    cbxButton1.SelectedIndex.ToString(),
                                    cbxButton2.SelectedIndex.ToString(),
                                    cbxButton3.SelectedIndex.ToString(),
                                    cbxButton4.SelectedIndex.ToString(),
                                    cbxButton5.SelectedIndex.ToString(),
                                    cbxButton6.SelectedIndex.ToString(),
                                    cbxButton7.SelectedIndex.ToString(),
                                    cbxButton8.SelectedIndex.ToString(),
                                    cbxButton9.SelectedIndex.ToString(),
                                    cbxButton10.SelectedIndex.ToString(),
                                    cbxButton11.SelectedIndex.ToString(),
                                    cbxButton12.SelectedIndex.ToString(),
                                    cbxLeftTrigger.SelectedIndex.ToString(),
                                    cbxRightTrigger.SelectedIndex.ToString() };

                        // Write to file
                        System.IO.File.WriteAllLines(@"" + savedFileName, saveData);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An unexpected error has occured:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        e.Cancel = true;
                    }
                }
                else if (exitSaving == DialogResult.Cancel)
                {
                    // Do nothing / close form
                    e.Cancel = true;
                }
            }
            // If changes have been made but they are not yet saved to a file,
            // check if they want to save to a new file
            else if (changesMade && !fileOpened)
            {
                DialogResult saveFileAndExit = MessageBox.Show("The keybinds on the form have not been saved.\n\nWould you like to make a new save with these binds?", "Project: S.P.I.K.E.D", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (saveFileAndExit == DialogResult.Yes)
                {
                    // Get keybinds and store in array
                    string[] saveData = {   cbxButton0.SelectedIndex.ToString(),
                                    cbxButton1.SelectedIndex.ToString(),
                                    cbxButton2.SelectedIndex.ToString(),
                                    cbxButton3.SelectedIndex.ToString(),
                                    cbxButton4.SelectedIndex.ToString(),
                                    cbxButton5.SelectedIndex.ToString(),
                                    cbxButton6.SelectedIndex.ToString(),
                                    cbxButton7.SelectedIndex.ToString(),
                                    cbxButton8.SelectedIndex.ToString(),
                                    cbxButton9.SelectedIndex.ToString(),
                                    cbxButton10.SelectedIndex.ToString(),
                                    cbxButton11.SelectedIndex.ToString(),
                                    cbxButton12.SelectedIndex.ToString(),
                                    cbxLeftTrigger.SelectedIndex.ToString(),
                                    cbxRightTrigger.SelectedIndex.ToString() };

                    // Make SaveFileDialog object for saving file and set its properties
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "dat files (*.dat)|*.dat";
                    saveFileDialog.FilterIndex = 2;
                    saveFileDialog.RestoreDirectory = true;
                    saveFileDialog.DefaultExt = ".dat";

                    // Save the file as the name they typed
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            // Write to file
                            System.IO.File.WriteAllLines(@"" + saveFileDialog.FileName, saveData);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("An unexpected error has occured:" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            e.Cancel = true;
                        }
                    }
                    // If they cancel the save file window, cancel the form closing
                    else
                    {
                        e.Cancel = true;
                    }
                }
                // If they cancel the dialog window, cancel the form closing
                else if (saveFileAndExit == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
            // If a file hasn't been opened and changes have not been made, make sure they want to exit the program
            else
            {
                DialogResult exit = MessageBox.Show("Are you sure you want to close Project: S.P.I.K.E.D.?", "Project: S.P.I.K.E.D", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // If user is not sure / if user doesnt press yes, cancel form closing
                if (exit != DialogResult.Yes)
                {
                    e.Cancel = true;
                }
            }
        }

        private void HandleButton(int selectedIndex, int i)
        {
            // if button is pressed
            if (buttons[i])
            {
                // if key has not been pressed yet
                if (!buttonsLogic[i])
                {
                    // Handles key press

                    // if left click is selected and has not yet been pressed
                    if (selectedIndex == 37)
                    {
                        // press left click
                        mouse_event(MOUSEEVENT_LEFTDOWN, 0, 0, 0, 0);

                        // set button i logic bool to true
                        buttonsLogic[i] = true;
                    }
                    // if right click is selected and has not yet been pressed
                    else if (selectedIndex == 38)
                    {
                        // press right click
                        mouse_event(MOUSEEVENT_RIGHTDOWN, 0, 0, 0, 0);

                        // set button i logic bool to true
                        buttonsLogic[i] = true;
                    }
                    // if button is not a left or right click and button has not been pressed
                    else
                    {
                        // press button
                        keybd_event(buttonBindings[selectedIndex], 0, 0x0001 | 0, 0);

                        // set button i logic bool to true
                        buttonsLogic[i] = true;
                    } 
                }
            }
            // if right click is clicked and button logic bool is true
            else if (buttonsLogic[i] && selectedIndex == 38)
            {
                // unpress right click
                mouse_event(MOUSEEVENT_RIGHTUP, 0, 0, 0, 0);

                // reset bool logic variable
                buttonsLogic[i] = false;
            }
            // if left click is clicked and button logic bool is true
            else if (buttonsLogic[i] && selectedIndex == 37)
            {
                // unpress left click
                mouse_event(MOUSEEVENT_LEFTUP, 0, 0, 0, 0);

                // reset bool logic variable
                buttonsLogic[i] = false;
            }
            // if button has been pressed and is a key
            else if (buttonsLogic[i])
            {
                // upress key
                keybd_event(buttonBindings[selectedIndex], 0, 0x0001 | 0x0002, 0);

                // reset bool logic variable
                buttonsLogic[i] = false;
            }
        }

        private void HandleKeyPress(int selectedIndex, int i)
        {
            // Handles key press

            // if left click is selected and has not yet been pressed
            if (selectedIndex == 37 && leftClick == false)
            {
                // press left click
                mouse_event(MOUSEEVENT_LEFTDOWN, 0, 0, 0, 0);

                // set button i logic bool to true and left click bool to true
                buttonsLogic[i] = true;
                leftClick = true;
            }
            // if right click is selected and has not yet been pressed
            else if (selectedIndex == 38 && rightClick == false)
            {
                // press right click
                mouse_event(MOUSEEVENT_RIGHTDOWN, 0, 0, 0, 0);

                // set button i logic bool to true and right click bool to true
                buttonsLogic[i] = true;
                rightClick = true;
            }
            // if button is not a left or right click and button has not been pressed
            else if (buttonsLogic[i] == false)
            {
                // press button
                keybd_event(buttonBindings[selectedIndex], 0, 0x0001 | 0, 0);

                // set button i logic bool to true
                buttonsLogic[i] = true;
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Open webpage on fefault browser
            Process.Start("https://austinvanbockern.github.io/csharp.html");
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == this.WindowState)
            {
                not_spiked.ShowBalloonTip(500);
                this.Hide();
            }
        }

        private void not_spiked_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
            this.Activate();
            this.WindowState = FormWindowState.Normal;
            this.Focus();
            this.BringToFront();
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem.Text == "Open Window")
            {
                this.Show();
                this.Activate();
                this.WindowState = FormWindowState.Normal;
                this.Focus();
                this.BringToFront();
            }
            if (e.ClickedItem.Text == "Exit")
            {
                not_spiked.Visible = false;
                this.Close();
            }
        }
    }
}